// CS210 mod one Hello World.cpp : This file contains the 'main' function. Program execution begins and ends there.
//Briana Long
// Module One Assignent


#include <iostream>

int main()
{
    std::cout << "Hello World!\n";  //print hello, world!
}

