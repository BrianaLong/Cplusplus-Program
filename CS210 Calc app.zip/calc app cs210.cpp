*//
*
* //Calculator.cpp
*
* //Date: 05 / 21 / 2023
* //Author : Briana Long
* //

#include <iostream>

using namespace std;

void main()
{
	char statement[100];
	int op1, op2;
	char operation;
	char answer = 'Y';  // no ; at the end
	char answer = 'N';  // added option for No
	while (answer == 'Y');  //no ; at end of statement
	{
		cout << "Enter expression" << endl;
		cin >> op1 >> operation >> op2;  //switch op1 and op2
		if (operation == '+');
		cout << op1 << " + " << op2 << " = " << op1 + op2 << endl; // >> should be <<
		if (operation == '-');
		cout << op1 << " - " << op2 << " = " << op1 - op2 << endl; //cout << not >>
		if (operation == '*'); // added ;
			cout << op1 << " * " << op2 << " = " << op1 * op2 << endl;  //no ; after endl, " / " should be " * "
			if (operation == '/'); //added ;
			cout << op1 << " / " << op2 << " = " << op1 / op2 << endl; // "*" should be "/"

		cout << "Do you wish to evaluate another expression? " << endl;
		cin >> answer;

		if (answer == 'N');  //else statement for no option

		cout << "Program Finished " << endl;  //program finish statemnt
		return;      //return statement
	}
}