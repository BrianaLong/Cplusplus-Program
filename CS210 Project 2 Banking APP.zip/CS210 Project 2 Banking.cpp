// Briana Long
//CS210 Project 2
// Banking application


#inlcude <iostream>
#include <iomanip>

using namespace std;

int main() {
	//declarations
	float initalInvestment, monthlyDesposit, annualInterest, months, years;
	float totalAmount, intAmount, yearTotalInsterest;

	//display menu to print
	cout << "*******************************" \n;
	cout << "**********Data Input***********" \n;
	cout << "Initial Investment Amount: " \n;
	cout << "Monthly Desposit: " \n;
	cout << "Annual Intrest:  " \n;
	cout << "Number of Years: " \n;

	//get data from the user and print
	cout << "*******************************" \n;
	cout << "**********Data Input***********" \n;
	cout << "Initial Investment Amount:  $";
	cin >> initalInvestment;
	cout << "Monthly Desposit: ";
	cin >> monthlyDesposit;
	cout << "Annual Interest: % ";
	cin >> annualInterest;
	cout << "Number of Years: ";
	cin >> years;
	//equation for months
	months = years * 12;

	//set totalAMount to be updated to inital Investments
	totalAmount = initalInvestment;

	//display the years data WITHOUT monthly deposits
	cout << "Balance and Interest Without Additional Monthly Deposits" \n;
	cout << "===========================================================" \n;
	cout << "Year \t Year End Balance \t Year End Earned Interest" \n;
	cout << "-----------------------------------------------------------" \n;

	//calculations for yearly interest, year end total, and setprecision for two decimal points $0.00 for money
	for (int i = 0; i < years; i++) {
		intAmount = (totalAmount) * ((annualInterest / 100));
		totalAmount = totalAmount + intAmount;
		cout << (i + 1) << "$" << fixed << setprecision(2) << totalAmount << "$" << intAmount << " ";
	}

	//set totalAMount to be updated by interest
	totalAmount = initalInvestment;

	//display the years data WITH monthly deposits
	cout << "Balance and Interest With Additional Monthly Deposits" \n;
	cout << "===========================================================" \n;
	cout << "Year \t Year End Balance \t Year End Earned Interest" \n;
	cout << "-----------------------------------------------------------" \n;

	//total interest calculations
	for (int i = 0; i < years; i++) {
		yearTotalInsterest = 0;

	}
	//total amount + interest
	for (int j = 0; j < 12; j++) {
		intAmount = (totalAmount + monthlyDesposit) * ((annualInterest / 100) / 12);
		yearTotalInsterest = yearTotalInsterest + intAmount;
		totalAmount = totalAmount + monthlyDesposit + intAmount;
	}

	//print table with the proper decimals
	cout << (i + 1) << "$" << fixed << setprecision(2) << totalAmount << "$" << yearTotalInsterest << " ";
}

return 0;
}