// Briana Long
// CS210 Project 3
// Item tracking program for Corner Grocer
//


#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>

//Retrieves the item frequency of the choosen item
int getItemFrequency(const std::string & Item) {
	std::ifstream inputFile("Inventory.txt");
	std::string word;
	int frequency = 0;

	while (inputFile >> word) {
		if (word == Item) {
			frequency++;
		}
	}
	return frequency;
}

int main() {
	std::string Item;
	std::cout << "Enter an item to search for: ";
	std::cin >> Item;

	int frequency = getItemFrequency(Item);
	std::cout << "Frequency of " << Item << ": " << frequency << std::endl;

	return 0;
}

//Prints the item frequency for choosen item

void printItemFrequency() {
	std::ifstream inputFile("Inventory.txt");
	std::string word;
	std::unordered_map<std::string, int> ItemFrequencies;

	while (inputFile >> word) {
		ItemFrequencies[word]++;
	}

	for (const auto& pair) {
		std::cout << pair.first << ": " << pair.second << std::endl;
	}
}

int main() {
	printItemFrequency();

	return 0;
}

//prints a * histogram for choosen witem
void printItemHistogram() {
	std::ifstream inputFile("Inventory.txt");
	std::string word;
	std::unordered_map<std::string, int> ItemFrequencies;

	while (inputFile >> word) {
		ItemFrequencies[word]++;
	}

	for (const auto& pair : ItemFrequencies) {
		std::cout << pair.first << " ";
		for (int i = 0; i < pair.second; i++) {
			std::cout << "*";
		}
		std::cout << std::endl;
	}
}

int main() {
	printItemHistogram();

	return 0;
}


//Menu options and exit. Options outside of the choices is invalid. Cases corespond to number choice in the menu.
int main() {
	int choice = 0;
	while (choice != 4) {
		std::cout << "Menu Options: " << std::endl;
		std::cout << "1 - Search for an item and get the frequency. " << std::endl;
		std::cout << "2 - Print list of items with it's frequencies. " << std::endl;
		std::cout << "3 - Print the histogram of the item frequencies. " << std::endl;
		std::cout << "4 - Exit program. " << std::endl;
		std::cout << "Enter your choices of 1 to 4. " << std::endl;
		std::cin >> choice;

		switch (choice) {
		case 1: {
			break;
		}
		case 2: {
			break;
		}
		case 3: {
			break;
		}
		case 4: {
			std::cout << "Exiting the program. " << std::endl;
			break;
		}
		default: {
			std::cout << "Invalid choice. Please input a number 1 to 4." << std::endl;
			break;
		}
	}

	return 0;
}



//frequency.dat for backuping up the accumulated data

	void backupItemFrequencies(); {
	std::ifstream inputFile("Inventory.txt");
	std::ofstream outputFile("frequency.dat");
	std::string word;
	std::unordered_map < std::string, int> ItemFrequencies;

	while (inputFile >> word) {
		ItemFrequencies[word]++;
	}

	for (const auto& pair : ItemFrequencies) {
		outputFile << pair.first << ": " << pair.second << std::endl;
	}
}

	int main(); {
	backupItemFrequencies();

	return 0;
}