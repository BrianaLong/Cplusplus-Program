// CS210 Mod FiveTemp.cpp 
//Briana Long
//

#include <iostream>
//allows use of ifstream
#include <fstream> 
#include <string>

using namespace std;

int main()
{
    //Declarations
    ifstream inFS;
    ofstream outFS;
    string cityName;
    int tempFarenheit;
    double tempCelsius;

    //open Farenheit file
    inFS.open("FarenheitTemperature.txt");

    //Create/open Celsius file
    outFS.open("CelsiusTemperature.txt");

    //converts temp from Farenheit to celsius. Then it is added to the celsius text file
    while (inFS >> cityName >> tempFarenheit) {
        tempCelsius = (tempFarenheit - 32) * ((double)5 / (double)9);
        outFS << cityName << " " << tempCelsius << endl;
    }

    //command to close files
    inFS.close();
    outFS.close();

    return 0;
}